package gr.aade.ops.taxation.migration.aade_taxation_migration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AadeTaxationMigrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AadeTaxationMigrationApplication.class, args);
	}

}
