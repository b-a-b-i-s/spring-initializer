package gr.aade.ops.taxation.migration.aade_taxation_migration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AadeTaxationMigrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
